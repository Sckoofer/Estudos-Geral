Projetos em C++

Uma breve descrição de cada projeto


-> Avaliação de Perfil - Questionário 2: (92% concluído)

Realiza a avaliação de cada entrevistado pelas perguntas respondidas por eles. As respostas corretas correspondem ao perfil
desejado pelo entrevistador.


Vestimentas, struct:
Permite o usuário escolher os conjuntos de roupas.



Questionário Simples:
A primeira versão questionário 2.
